IMPORTED_LINK_INTERFACE_MULTIPLICITY
------------------------------------

Repetition count for cycles of ``IMPORTED`` static libraries.

This is :prop_tgt:`LINK_INTERFACE_MULTIPLICITY` for ``IMPORTED`` targets.
