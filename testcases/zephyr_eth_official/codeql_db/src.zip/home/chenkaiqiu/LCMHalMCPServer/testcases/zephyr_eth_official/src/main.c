/*
 * Copyright (c) 2024 Zephyr Community
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Zephyr ETH Driver Test - Simplified version for Zephyr 4.3
 * Focuses on MMIO register access for CodeQL analysis
 * 
 * This test demonstrates basic MMIO operations for ETH peripheral analysis:
 * 1. MMIO register access simulation
 * 2. Register read/write operations
 * 3. Interrupt status checking
 */

#include <zephyr/kernel.h>
#include <zephyr/logging/log.h>

LOG_MODULE_REGISTER(eth_test, LOG_LEVEL_INF);

/* ETH register access functions (simulated MMIO for analysis) */
static volatile uint32_t *eth_mmio_base = (volatile uint32_t *)0x40028000;

#define ETH_MACCR      (eth_mmio_base + 0x00)  /* MAC Control Register */
#define ETH_MACFFR     (eth_mmio_base + 0x04)  /* MAC Frame Filter */
#define ETH_MACMIIAR   (eth_mmio_base + 0x10)  /* MAC MII Address */
#define ETH_MACMIIDR   (eth_mmio_base + 0x14)  /* MAC MII Data */
#define ETH_MACFCR     (eth_mmio_base + 0x18)  /* MAC Flow Control */
#define ETH_MACVLANTR  (eth_mmio_base + 0x1C)  /* MAC VLAN Tag */

/* ETH DMA registers */
static volatile uint32_t *eth_dma_base = (volatile uint32_t *)0x40029000;

#define ETH_DMABMR     (eth_dma_base + 0x00)   /* DMA Bus Mode */
#define ETH_DMATPDR    (eth_dma_base + 0x04)   /* DMA Transmit Poll Demand */
#define ETH_DMARPDR    (eth_dma_base + 0x08)   /* DMA Receive Poll Demand */
#define ETH_DMARDLAR   (eth_dma_base + 0x0C)   /* DMA Receive Descriptor List */
#define ETH_DMATDLAR   (eth_dma_base + 0x10)   /* DMA Transmit Descriptor List */
#define ETH_DMASR      (eth_dma_base + 0x14)   /* DMA Status */
#define ETH_DMAOMR     (eth_dma_base + 0x18)   /* DMA Operation Mode */
#define ETH_DMAIER     (eth_dma_base + 0x1C)   /* DMA Interrupt Enable */

/* ETH MMIO register access test */
static void eth_test_mmio_access(void)
{
    LOG_INF("Testing ETH MMIO register access...");
    
    /* Write to MAC Control Register */
    *ETH_MACCR = 0x00008000;  /* Enable receiver */
    uint32_t maccr_value = *ETH_MACCR;
    LOG_INF("MACCR: write=0x%08x, read=0x%08x", 0x00008000, maccr_value);
    
    /* Write to MAC Frame Filter Register */
    *ETH_MACFFR = 0x00000002;  /* Pass all multicast */
    uint32_t macffr_value = *ETH_MACFFR;
    LOG_INF("MACFFR: write=0x%08x, read=0x%08x", 0x00000002, macffr_value);
    
    /* Configure DMA */
    *ETH_DMABMR = 0x00020101;  /* Fixed burst, 32-bit addressing */
    uint32_t dmabmr_value = *ETH_DMABMR;
    LOG_INF("DMABMR: write=0x%08x, read=0x%08x", 0x00020101, dmabmr_value);
    
    /* Enable DMA interrupts */
    *ETH_DMAIER = 0x00001000;  /* Enable normal interrupt summary */
    uint32_t dmaier_value = *ETH_DMAIER;
    LOG_INF("DMAIER: write=0x%08x, read=0x%08x", 0x00001000, dmaier_value);
    
    LOG_INF("ETH MMIO register access test completed");
}

/* ETH register read/write pattern test */
static void eth_test_register_patterns(void)
{
    LOG_INF("Testing ETH register patterns...");
    
    /* Test pattern 1: Sequential writes */
    for (int i = 0; i < 4; i++) {
        *(eth_mmio_base + i) = 0x1000 * (i + 1);
        LOG_INF("Reg[%d] = 0x%08x", i, *(eth_mmio_base + i));
    }
    
    /* Test pattern 2: Bit manipulation */
    uint32_t control_reg = *ETH_MACCR;
    control_reg |= 0x00000001;  /* Set bit 0 */
    control_reg &= ~0x00000002; /* Clear bit 1 */
    *ETH_MACCR = control_reg;
    LOG_INF("MACCR bit manipulation: 0x%08x", *ETH_MACCR);
    
    /* Test pattern 3: DMA register interaction */
    *ETH_DMATPDR = 0x00000100;
    *ETH_DMARPDR = 0x00000100;
    LOG_INF("DMA poll registers set: TPDR=0x%08x, RPDR=0x%08x", 
            *ETH_DMATPDR, *ETH_DMARPDR);
    
    LOG_INF("ETH register patterns test completed");
}

/* Main application thread */
int main(void)
{
    LOG_INF("Zephyr ETH MMIO Test Started (Zephyr 4.3)");
    
    /* Test basic MMIO register access */
    eth_test_mmio_access();
    
    /* Test register patterns */
    eth_test_register_patterns();
    
    /* Main loop - simulate periodic MMIO operations */
    uint32_t counter = 0;
    while (1) {
        /* Simulate periodic register updates */
        k_sleep(K_MSEC(1000));
        
        /* Check DMA status register */
        uint32_t dma_status = *ETH_DMASR;
        if (dma_status & 0x00001000) {
            LOG_INF("DMA interrupt detected: 0x%08x", dma_status);
            /* Clear interrupt status bit */
            *ETH_DMASR = dma_status & ~0x00001000;
        }
        
        /* Update transmit poll demand register */
        *ETH_DMATPDR = counter++;
        
        /* Read back to verify */
        uint32_t readback = *ETH_DMATPDR;
        
        LOG_INF("Cycle %u: DMATPDR=0x%08x, DMASR=0x%08x", 
                counter, readback, dma_status);
        
        /* Limit test cycles */
        if (counter >= 10) {
            LOG_INF("Test completed after %u cycles", counter);
            break;
        }
    }
    
    LOG_INF("ETH MMIO test finished successfully");
    return 0;
}
