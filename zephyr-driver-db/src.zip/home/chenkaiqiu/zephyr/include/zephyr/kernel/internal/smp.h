/*
 * Copyright (c) 2023 Intel Corporation
 *
 * SPDX-License-Identifier: Apache-2.0
 */
#ifndef ZEPHYR_INCLUDE_KERNEL_INTERNAL_SMP_H_
#define ZEPHYR_INCLUDE_KERNEL_INTERNAL_SMP_H_

void z_sched_ipi(void);

#endif /* ZEPHYR_INCLUDE_KERNEL_INTERNAL_SMP_H_ */
