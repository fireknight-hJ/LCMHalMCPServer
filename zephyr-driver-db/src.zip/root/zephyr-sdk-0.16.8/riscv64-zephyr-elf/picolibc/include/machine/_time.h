/* Copyright (c) 2016 Sebastian Huber <sebastian.huber@embedded-brains.de> */
#ifndef _SYS_TIME_H_
#error "must be included via <sys/time.h>"
#endif /* !_SYS_TIME_H_ */
